package com.alibaba.sca.temp;

import org.junit.jupiter.api.Test;

/** 单元测试，CloudIDE测试
 * @author ningzhong.wyl
 *
 */
class TestHelloworld {

	@Test
	void test() {
		System.out.println("helloworld");
	}

}
